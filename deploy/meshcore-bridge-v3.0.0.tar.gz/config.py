"""
Módulo de Configuración para MeshCore Bridge.
Carga variables de entorno desde un archivo .env si existe o desde el sistema.
"""

import os
from pathlib import Path

# Cargar archivo .env desde el directorio del proyecto
env_path = Path(__file__).resolve().parent / ".env"
try:
    from dotenv import load_dotenv
    load_dotenv(dotenv_path=env_path, override=False, interpolate=True)
except ImportError:
    # Fallback si python-dotenv no está instalado: parser nativo de .env
    if env_path.is_file():
        try:
            with open(env_path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        k = k.strip()
                        v = v.strip().strip("\"'")
                        if k and k not in os.environ:
                            os.environ[k] = v
        except Exception:
            pass

def _safe_int(key: str, default: int) -> int:
    val = os.getenv(key, str(default))
    try:
        return int(val)
    except (ValueError, TypeError):
        return default

def _safe_float(key: str, default: float) -> float:
    val = os.getenv(key, str(default))
    try:
        return float(val)
    except (ValueError, TypeError):
        return default

# ================= Configuración Serial =================
SERIAL_PORT = os.getenv("SERIAL_PORT", "/dev/ttyACM0")
BAUD_RATE = _safe_int("BAUD_RATE", 115200)
SERIAL_TIMEOUT = _safe_float("SERIAL_TIMEOUT", 30.0)

# ================= Configuración MQTT =================
MQTT_BROKER = os.getenv("MQTT_BROKER", "127.0.0.1")
MQTT_PORT = _safe_int("MQTT_PORT", 1883)
MQTT_USER = os.getenv("MQTT_USER", "").strip() or None
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "").strip() or None
MQTT_PASSWORD_MASKED = "****" if MQTT_PASSWORD else ""
MQTT_KEEPALIVE = _safe_int("MQTT_KEEPALIVE", 60)

# ================= Tópicos MQTT =================
TOPIC_PREFIX = os.getenv("TOPIC_PREFIX", "meshcore").strip("/")

TOPIC_STATE       = f"{TOPIC_PREFIX}/bridge/state"      # LWT: online / offline (retained)
TOPIC_HEALTH      = f"{TOPIC_PREFIX}/bridge/health"     # Reporte periódico de salud y métricas
TOPIC_RX_ALL      = f"{TOPIC_PREFIX}/rx/all"           # Tópico unificado para todos los eventos RX
TOPIC_RX_PUBLIC   = f"{TOPIC_PREFIX}/rx/public"        # Canal 0 / broadcast
TOPIC_RX_CHANNEL  = f"{TOPIC_PREFIX}/rx/channel"       # Canales secundarios: {prefix}/rx/channel/ch_{idx}
TOPIC_RX_DIRECT   = f"{TOPIC_PREFIX}/rx/direct"        # Mensajes directos: {prefix}/rx/direct/{sender_id}
TOPIC_RX_TELEMETRY= f"{TOPIC_PREFIX}/rx/telemetry"     # Batería, voltaje y métricas de nodos
TOPIC_RX_NODES    = f"{TOPIC_PREFIX}/rx/nodes"         # Anuncios y nodos descubiertos
TOPIC_RX_LOG      = f"{TOPIC_PREFIX}/rx/log"           # Streaming de logs RF y sniffer de paquetes

TOPIC_TX          = f"{TOPIC_PREFIX}/tx"               # Entrada de transmisión (n8n -> Heltec)
TOPIC_TX_STATUS   = f"{TOPIC_PREFIX}/tx/status"        # Confirmación / ACK de transmisión

TOPIC_ADMIN_CMD   = f"{TOPIC_PREFIX}/admin/cmd"        # Entrada de comandos de administración
TOPIC_ADMIN_STAT  = f"{TOPIC_PREFIX}/admin/status"     # Respuesta de comandos de administración
TOPIC_ADMIN_REPEATER = f"{TOPIC_PREFIX}/admin/repeater" # Gestión remota de repetidores por RF

MQTT_MAX_PAYLOAD_BYTES = _safe_int("MQTT_MAX_PAYLOAD_BYTES", 128 * 1024)

# ================= Parámetros de Resiliencia y Control =================
TX_INTERVAL_SEC = _safe_float("TX_INTERVAL_SEC", 1.0)                 # Espaciado de transmisión RF (LoRa Rate Limiter)
DEDUPLICATION_WINDOW_SEC = _safe_float("DEDUPLICATION_WINDOW_SEC", 60.0) # Ventana temporal de deduplicación de paquetes en RAM (segundos)
WATCHDOG_INTERVAL_SEC = _safe_float("WATCHDOG_INTERVAL_SEC", 60.0)     # Intervalo de supervisión de vivacidad serial
HEALTH_METRICS_INTERVAL_SEC = _safe_float("HEALTH_METRICS_INTERVAL_SEC", 60.0) # Intervalo de reporte de salud
MAX_RECONNECT_ATTEMPTS = _safe_int("MAX_RECONNECT_ATTEMPTS", 0)       # 0 = reintentos ilimitados
NODE_REGISTRY_STORAGE_PATH = os.getenv("NODE_REGISTRY_STORAGE_PATH", os.path.join("data", "node_registry.json"))

# ================= Parámetros de Concurrencia (Nuevos) =================
MAX_TX_QUEUE_SIZE = _safe_int("MAX_TX_QUEUE_SIZE", 500)
MAX_RX_CONCURRENCY = _safe_int("MAX_RX_CONCURRENCY", 20)
WS_IDLE_TIMEOUT_SEC = _safe_float("WS_IDLE_TIMEOUT_SEC", 30.0)

# ================= Parámetros de Radio y Airtime LoRa =================
LORA_DEFAULT_SF = _safe_int("LORA_DEFAULT_SF", 11)                     # Spreading Factor por defecto (SF7..SF12)
LORA_DEFAULT_BW_KHZ = _safe_float("LORA_DEFAULT_BW_KHZ", 250.0)       # Ancho de banda en kHz (125, 250, 500)
LORA_DEFAULT_CR = _safe_int("LORA_DEFAULT_CR", 5)                      # Coding Rate (5 = 4/5, 6 = 4/6, etc.)
LORA_PREAMBLE_LEN = _safe_int("LORA_PREAMBLE_LEN", 8)                 # Símbolos de preámbulo

# ================= Servidor Web Embebido y Cliente Web SPA =================
WEB_ENABLED = os.getenv("WEB_ENABLED", "true").lower() in ("true", "1", "yes")
WEB_HOST = os.getenv("WEB_HOST", "0.0.0.0")
WEB_PORT = _safe_int("WEB_PORT", 8080)
BRIDGE_API_KEY = os.getenv("BRIDGE_API_KEY", "")
BRIDGE_ALLOWED_ORIGINS = os.getenv("BRIDGE_ALLOWED_ORIGINS", "http://localhost:8080,http://127.0.0.1:8080")

# ================= Servidor TCP Companion (App Móvil Oficial / CLI) =================
TCP_SERVER_ENABLED = os.getenv("TCP_SERVER_ENABLED", "true").lower() in ("true", "1", "yes")
TCP_SERVER_HOST = os.getenv("TCP_SERVER_HOST", "0.0.0.0")
TCP_SERVER_PORT = _safe_int("TCP_SERVER_PORT", 5000)
MAX_COMPANION_CLIENTS = _safe_int("MAX_COMPANION_CLIENTS", 8)
COMPANION_ALLOWED_IPS = os.getenv("COMPANION_ALLOWED_IPS", "")
COMPANION_TOKEN = os.getenv("COMPANION_TOKEN", "")

# ================= Logging Persistente y Rotación de Archivos =================
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_DIR = os.getenv("LOG_DIR", "logs")
LOG_FILE_PATH = os.getenv("LOG_FILE_PATH", os.path.join(LOG_DIR, "meshcore-bridge.log"))
LOG_ERROR_FILE_PATH = os.getenv("LOG_ERROR_FILE_PATH", os.path.join(LOG_DIR, "meshcore-bridge.error.log"))
LOG_MAX_BYTES = _safe_int("LOG_MAX_BYTES", 5 * 1024 * 1024)       # 5 MB por archivo antes de rotar
LOG_BACKUP_COUNT = _safe_int("LOG_BACKUP_COUNT", 3)                # Mantener hasta 3 copias históricas (.1, .2, .3)

# ================= Base de Datos =================
SQLITE_DB_PATH = os.getenv("SQLITE_DB_PATH", "data/meshcore_buffer.db")

def _validate_config() -> None:
    import sys
    errors: list[str] = []
    warnings: list[str] = []
    
    # Spreading Factor
    if not (7 <= LORA_DEFAULT_SF <= 12):
        errors.append(f"LORA_DEFAULT_SF={LORA_DEFAULT_SF} must be in range 7-12")
    
    # Bandwidth
    if LORA_DEFAULT_BW_KHZ not in (125.0, 250.0, 500.0):
        warnings.append(f"LORA_DEFAULT_BW_KHZ={LORA_DEFAULT_BW_KHZ} is non-standard (use 125, 250, or 500)")
    
    # Ports
    if not (1 <= MQTT_PORT <= 65535):
        errors.append(f"MQTT_PORT={MQTT_PORT} must be in range 1-65535")
    if not (1 <= WEB_PORT <= 65535):
        errors.append(f"WEB_PORT={WEB_PORT} must be in range 1-65535")
    if not (1 <= TCP_SERVER_PORT <= 65535):
        errors.append(f"TCP_SERVER_PORT={TCP_SERVER_PORT} must be in range 1-65535")
    
    # Baud rate
    if BAUD_RATE not in (9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600):
        warnings.append(f"BAUD_RATE={BAUD_RATE} is non-standard")
    
    # Timeouts
    if WATCHDOG_INTERVAL_SEC < 5.0:
        warnings.append(f"WATCHDOG_INTERVAL_SEC={WATCHDOG_INTERVAL_SEC} < 5s may cause false disconnects")
    if WS_IDLE_TIMEOUT_SEC < 5.0:
        warnings.append(f"WS_IDLE_TIMEOUT_SEC={WS_IDLE_TIMEOUT_SEC} < 5s may cause premature WS disconnects")
    
    import logging as _log
    for w in warnings:
        _log.warning(f"[CONFIG] {w}")
    if errors:
        for e in errors:
            _log.critical(f"[CONFIG] FATAL: {e}")
        sys.exit("Configuration errors found. Fix your .env file.")

_validate_config()
