# Explicación Técnica del Código: MeshCore Universal Bridge

Este documento detalla la arquitectura, decisiones de diseño, flujo de concurrencia, mecanismos de resiliencia de grado industrial (**Persistencia Atómica JSON**, **LoRa Rate Limiter**, **Serial Watchdog**, **Health Metrics**) y el funcionamiento del núcleo **`src/bridge_core.py`** (la clase `MeshCoreBridge`) y su CLI wrapper/entrypoint **`meshcore_bridge.py`**, con cualquier placa compatible (Heltec, LilyGO, RAKwireless, Seeed, RP2040) y el workflow de **n8n**.

---

## 1. Arquitectura de Concurrencia (Asyncio + Threading)

Uno de los aspectos más críticos al integrar la librería `meshcore` (basada en `asyncio`) con `paho-mqtt` (basada en hilos del sistema operativo) es garantizar la seguridad entre hilos (*thread safety*) y evitar bloqueos del bucle de eventos.

```mermaid
sequenceDiagram
    participant OS as Sistema Operativo
    participant MQTT_Th as Hilo de Red Paho MQTT
    participant Loop as Event Loop Asyncio (Python)
    participant MC as Placa MeshCore (Heltec / LilyGO / RAK / Seeed)
    participant n8n as Motor n8n

    Note over MQTT_Th,Loop: 1. Ingesta de Comando desde MQTT
    n8n->>MQTT_Th: Publica en meshcore/tx
    MQTT_Th->>Loop: asyncio.run_coroutine_threadsafe(handle_tx)
    Loop->>MC: await mc.commands.send_chan_msg()
    MC-->>Loop: Confirmación RF
    Loop->>MQTT_Th: mqtt_client.publish(meshcore/tx/status)
    MQTT_Th->>n8n: ACK de Transmisión

    Note over MC,Loop: 2. Evento RF Recibido de la Malla
    MC->>Loop: Dispara on_mesh_event(CHANNEL_MSG_RECV)
    Loop->>Loop: Normalizar Payload + Extraer Métricas
    Loop->>MQTT_Th: mqtt_client.publish(meshcore/rx/all & topic)
    MQTT_Th->>n8n: Evento JSON Ingerido
```

### Componentes de Sincronización:
1. **Hilo de Red MQTT (`self.mqtt_client.loop_start()`)**:
   - Paho MQTT corre en un hilo dedicado en segundo plano gestionando los paquetes TCP, pings de keepalive y recepción de mensajes.
2. **Puente Seguro hacia Asyncio (`asyncio.run_coroutine_threadsafe`)**:
   - Cuando el callback `on_mqtt_message` recibe datos desde el hilo de red MQTT, agenda la corrutina (`handle_tx` o `handle_admin`) en el `event_loop` principal de asyncio sin causar condiciones de carrera.
3. **Emisiones desde Asyncio hacia MQTT (`self.mqtt_client.publish`)**:
   - La función `publish()` de Paho MQTT es segura para hilos (*thread-safe*) y encola el paquete saliente inmediatamente en el buffer de transmisión del cliente.

---

## 2. Desglose de Módulos y Funciones

### A. Módulo de Configuración (`config.py`)
- Utiliza `python-dotenv` para cargar variables desde `.env`.
- Define valores por defecto seguros para puerto serial (`/dev/ttyACM0`), baudrate (`115200`) y broker MQTT (`127.0.0.1:1883`).
- Estandariza las constantes de tópicos bajo un prefijo común (`meshcore/...`), facilitando el cambio de namespace si conviven múltiples bridges.

---

### B. Inicialización y Gestión de Conexión (`MeshCoreBridge.run`)
- Establece la conexión serial con `MeshCore.create_serial(...)` pasando `auto_reconnect=True`.
- Invoca `ensure_contacts()` para cargar en memoria la libreta de contactos (nombres, alias y claves públicas asociadas a los nodos).
- Se suscribe a los eventos de la enumeración `EventType` de MeshCore v1.17 mediante `self.mc.subscribe(ev, self.on_mesh_event)`.
- Llama a `start_auto_message_fetching()` para vaciar automáticamente el buffer de mensajes de la radio cuando esta notifique `MESSAGES_WAITING`.

---

### C. Normalizador de Eventos (`MeshCoreBridge.on_mesh_event`)

#### 1. Corrección del Bug de Dos Puntos (`:`)
En la versión original, cualquier mensaje con `:` era cortado, asignando erróneamente la primera parte como `sender_name`.
**Solución implementada**:
- Primero se consulta la metadata nativa del evento (`payload.get('sender_name')`, `sender_id`, `pubkey_prefix`).
- Si no hay metadata, solo se intenta extraer el nombre si la primera parte es corta ($\le 20$ caracteres) y no es una URL (`http...`).
- Se preservan siempre los campos `text` (texto procesado) y `raw_text` (texto original íntegro).

#### 2. Extracción de Métricas de Radio (RF)
Se extraen métricas clave cuando el paquete LoRa las contiene:
- `rssi`: Nivel de intensidad de señal recibida en dBm.
- `snr`: Relación señal-ruido en dB.
- `hop_count`: Cantidad de saltos / repetidores por los que pasó el paquete.

#### 3. Modo Híbrido de Publicación MQTT
Cada mensaje procesado se publica simultáneamente en:
- **Tópico Específico**: `meshcore/rx/public`, `meshcore/rx/channel/ch_<idx>`, `meshcore/rx/direct/<id>`, `meshcore/rx/telemetry` o `meshcore/rx/nodes`.
- **Tópico Unificado**: `meshcore/rx/all` (ideal para que n8n no requiera múltiples nodos trigger).

---

### D. Manejador de Transmisión (`MeshCoreBridge.handle_tx`)
- **Tolerancia a Formatos**: Acepta objetos JSON estructurados y texto plano como fallback (convirtiéndolo automáticamente en broadcast canal 0).
- **Resolución de Nombres**: Si el campo `to` es un nombre (ej. `"Heltec_Router"`), `resolve_recipient_key` lo busca en la libreta de contactos y obtiene su clave pública real.
- **Acuse de Recibo (ACK)**: Publica en `meshcore/tx/status` un JSON con `status: "sent"` o `status: "error"` y el `request_id` enviado por n8n.

---

### E. Suite de Administración (`MeshCoreBridge.handle_admin`)
Permite invocar comandos de configuración del nodo Heltec desde MQTT:
- `get_config` / `status`: Información de radio, frecuencia, potencia y nombre local.
- `get_contacts`: Lista estructurada de contactos conocidos y último tiempo visto (`last_heard`).
- `set_name`: Modifica el nombre del nodo en el firmware.
- `set_tx_power`: Ajusta la potencia de salida en dBm.
- `req_telemetry`: Solicita telemetría a un nodo remoto.
- `reboot`: Reinicia el dispositivo Heltec.

---

### F. Apagado Limpio y Last Will & Testament (LWT)
- **LWT**: Al conectar, el cliente MQTT registra `meshcore/bridge/state = {"status": "offline"}` (retained). Si el proceso se interrumpe de forma anormal o se apaga la máquina, Mosquitto publica inmediatamente este estado.
- **Señales `SIGINT` / `SIGTERM`**: El manejador de señales llama a `bridge.shutdown()`, que:
  1. Cierra la sesión asíncrona de MeshCore y libera el puerto USB.
  2. Publica `{"status": "offline"}` explícito.
  3. Detiene el hilo de MQTT con `loop_stop()` y cierra la conexión TCP.

---

## 3. Lógica del Workflow n8n (`n8n_workflow_meshcore.json`)

```mermaid
flowchart LR
    MQTT["MQTT Trigger\n(meshcore/rx/all)"] --> CodeDedup["Code Node\n(Deduplicación 30s)"]
    CodeDedup --> IfNew{"¿Es Nuevo?"}
    IfNew -- No --> Drop["Descartar"]
    IfNew -- Sí --> Switch["Switch\n(Tipo de Evento)"]
    
    Switch -->|public| CodePub["Comandos /time, /date, /datetime\n+ Eco Público"]
    Switch -->|channel| CodeChan["Eco Canal Privado"]
    Switch -->|dm| CodeDM["/status, /admin\n+ Eco DM"]
    
    CodePub --> MQTTPub["MQTT Out\n(meshcore/tx)"]
    CodeChan --> MQTTPub
    CodeDM -->|Salida 1: TX| MQTTPub
    CodeDM -->|Salida 2: Admin| MQTTAdmin["MQTT Out\n(meshcore/admin/cmd)"]
```

### 1. Mecanismo de Deduplicación Anti-Relays
En redes LoRa Mesh, cuando un nodo emite un paquete, este puede ser recibido directamente por el bridge y, segundos más tarde, retransmitido por un nodo repetidor.
- En n8n, el nodo **"Deduplicar y Validar"** utiliza la memoria persistente del workflow (`$getWorkflowStaticData('global')`).
- Construye una clave única: `${event_type}_${sender_id}_${channel_index}_${text}`.
- Si la clave fue vista en los últimos 30 segundos, marca `is_duplicate = true`.
- Realiza limpieza automática de claves con más de 60 segundos de antigüedad para evitar fugas de memoria.

### 2. Procesamiento de Comandos
- **/time, /date, /datetime**: Genera respuestas formateadas en tiempo real.
- **/status**: Responde con métricas de salud y RSSI recibidas.
- **Eco de Confirmación**: Devuelve el texto recibido prefijado con `[Eco...]` para verificación inmediata del enlace bidireccional.
- **Lista Blanca de Administradores**: Verifica que el `sender_id` pertenezca a `ADMIN_WHITELIST` antes de reenviar comandos administrativos al Heltec, rechazando intentos no autorizados.

---

## 4. Mecanismos de Alta Disponibilidad y Resiliencia

### A. Persistencia Híbrida y Almacenamiento Atómico (Zero-Overhead)
- Los contactos, identificadores y claves se gestionan en memoria y se sincronizan directamente con la memoria Flash de la radio LoRa conectada.
- Los canales y configuraciones locales se persisten en disco de forma atómica en archivos JSON (`data/channels.json`), evitando bloqueos y minimizando el desgaste de tarjetas SD en micro-computadores (SBCs).
- El historial de mensajes y acuses de recibo (ACKs) se conserva en el navegador mediante `IndexedDB`, garantizando disponibilidad offline sin sobrecargar el servidor.

### B. Control de Congestión LoRa (TX Rate Limiter)
- Las transmisiones RF están reguladas por `_tx_worker()`, que procesa los elementos de `self.tx_queue` espaciando cada emisión por `TX_INTERVAL_SEC` (por defecto 1.0s).
- Esto protege el *duty cycle* de la banda ISM y evita que ráfagas de n8n saturen el chip transceptor SX1262.

### C. Watchdog Serial Activo (Anti-Bloqueos)
- La corrutina `_watchdog_loop()` verifica periódicamente si han transcurrido más de `WATCHDOG_INTERVAL_SEC` segundos sin actividad en el puerto.
- Si no hay tráfico, emite una consulta de baja intrusión (`get_contacts`). Si el puerto no responde dentro de la ventana de tiempo, cancela la sesión serial y fuerza la autoreconexión.

### D. Métricas en Tiempo Real (`meshcore/bridge/health`)
- La tarea `_health_reporter_loop()` emite periódicamente un reporte JSON con:
  - Uptime en segundos.
  - Conteo total de paquetes RX y TX.
  - Tasa de errores y estado de colas de transmisión.
  - Estado de conexión serial y MQTT.
  - Frecuencia y nombre del nodo LoRa.

---

## 5. Suite de Pruebas Automatizadas

El proyecto incluye **más de 30 archivos de test** (unitarias, fuzzing, concurrencia, E2E) organizados en:
1. **`test_bridge_logic.py`**: Parsing de caracteres `:`, fallback de texto plano en TX y deduplicación.
2. **`test_deduplicator.py`** y **`test_packet_buffer.py`**: Retención persistente con JSON y deduplicación en memoria RAM mediante `PacketBuffer` y `PacketDeduplicator` para la supervivencia a reinicios del proceso.
3. **`test_tx_rate_limiter.py`** y **`test_rate_limiter_priority.py`**: Espaciado temporal de paquetes LoRa y emisión de ACKs en `meshcore/tx/status`.
4. **`test_serial_watchdog.py`** y **`test_serial_adapter.py`**: Detección de bloqueos de hardware y reconexión automática.
5. **`test_e2e_simulation.py`**: Simulación completa End-to-End de nodo, MQTT y flujos n8n.
6. **`test_e2e_playwright.py`**: E2E en navegador real (Chromium Headless): envío de chat, auto-echo DM, aislamiento de canales, aislamiento multi-DM y auditoría de errores de consola.
7. **`test_stress_flood.py`** y **`test_fuzzing_and_edge_cases.py`**: Pruebas de estrés (500 paquetes RX / 50 TX) y fuzzing de tramas corruptas, truncadas y CRC inválidos.
8. **`test_web_server.py`** y **`test_websocket_live.py`**: Contratos REST y streaming WebSocket en vivo.
9. **`test_security_audit.py`**: Inyección SQL, Directory Traversal, DoS por payload gigante y cabeceras de seguridad.
10. **`test_virtual_mesh_simulation.py`** y **`test_concurrency_and_flapping.py`**: Malla virtual con Auto-Echo y caídas/flapping de conexión serial.
11. **`test_n8n_parser_matrix.py`**, **`test_contact_manager.py`**, **`test_protocol_types.py`**, **`test_sensor_decoder.py`** y **`test_repeater_manager.py`**: Contratos de parser, registro de nodos, tipos binarios, CayenneLPP y repetidores.

Para ejecutar toda la suite con verificación completa (pytest + mypy --strict + ruff):
```bash
python .agents/skills/bridge-test-runner/scripts/run_checks.py
```

---

## 6. Refactor de Clean Code: Componentes Extraídos y Nuevas APIs

Como parte de la auditoría de calidad (`clean-code-solid`), la *God Class* `MeshCoreBridge` (46 métodos) se dividió en **cuatro clases de responsabilidad única** más **cuatro Parameter Objects**. La API pública del bridge se conservó intacta mediante delegadores.

### 6.1 Nuevos módulos, clases y subpaquetes

| Módulo / Paquete | Clase(s) | Responsabilidad | Métodos extraídos de `MeshCoreBridge` |
| :--- | :--- | :--- | :--- |
| `src/rx_router.py` | `RxEventRouter` | Enrutamiento LoRa/RF → MQTT + WebSocket | `on_mesh_event`, `_handle_mesh_channel_msg`, `_handle_mesh_direct_msg`, `_handle_mesh_telemetry_msg`, `_dispatch_parsed_frame` |
| `src/health_reporter.py` | `HealthReporter` | Reporte periódico de salud MQTT | `_health_reporter_loop` |
| `src/admin_handler.py` | `AdminCommandHandler` | Comandos de administración RF/repetidores | `handle_admin` |
| `src/mqtt_dispatcher.py` | `MqttInboundDispatcher` | Mensajes MQTT entrantes (TX/Admin) | `_process_mqtt_input`, `_handle_tx_request`, `_handle_admin_request` |
| `src/routers/` | (Strategy Pattern) | Subpaquete con handlers de enrutamiento: `base.py`, `advert_handler.py`, `channel_handler.py`, `direct_handler.py`, `repeater_handler.py`, `system_handler.py`, `telemetry_handler.py` | Desacoplamiento de las estrategias de enrutamiento |
| `src/admin/` | (Command Pattern) | Subpaquete con ejecutores: `local_config_executor.py`, `repeater_executor.py`, `traceroute_executor.py`, `cli_command_executor.py` | Desacoplamiento de la ejecución de comandos y terminal CLI |
| `src/web/controllers/` | (MVC Pattern) | Subpaquete con controladores REST: `base.py`, `channels_controller.py`, `config_controller.py`, `contacts_controller.py`, `logs_controller.py`, `nodes_controller.py`, `packets_controller.py`, `repeater_controller.py`, `system_controller.py`, `tx_controller.py` | Desacoplamiento de endpoints REST por dominio funcional |
| `src/virtual_mesh_adapter.py` | `VirtualMeshAdapter` | Simulador de malla LoRa virtual | |
| `src/lqi_engine.py` | `LinkQualityEngine` | Motor de calidad de enlace (LQI/EMA) | |
| `src/diagnostics.py` | `Diagnostics` | Diagnóstico de enlaces y rotación de logs | |
| `src/target_resolver.py` | `TargetResolver` | Resolución de destinatarios y alias | |
| `src/tcp_companion_server.py` | `TCPCompanionServer` | Servidor TCP Companion (puerto 5000) | |
| `src/web/map_tile_service.py` | `MapTileService` | Servicio de teselas cartográficas offline | |
| `src/web/security_inspector.py` | `SecurityInspector` | Inspector de seguridad HTTP | |

Cada componente recibe sus dependencias mediante un **dataclass de contexto** (`RxRouterContext`, `HealthContext`, `AdminContext`, `MqttInboundContext`), evitando constructores con demasiados parámetros.

### 6.2 Parameter Objects introducidos

| Módulo | Dataclass | Firmas refactorizadas |
| :--- | :--- | :--- |
| `src/contact_manager.py` | `NodeContactUpdate`, `PacketRecord` | `add_or_update(public_key, update)` (19→2), `record_packet(event)` (7→1) |
| `src/rate_limiter.py` | `LoRaRadioConfig` | `estimate_lora_airtime_ms(payload_len_bytes, radio)` (8→2); `TxRateLimiter(radio_config=...)` |
| `src/packet_buffer.py` | `PacketBuffer` | Buffer circular de paquetes en RAM para retención y retransmisión |
| `src/mqtt_client.py` | `MQTTConfig` | `AsyncBridgeMQTTClient(config: MQTTConfig, ...)` (9→3) |
| `src/rx_router.py` | `MeshMessageEvent`, `BridgeCounters` (Protocol) | `_handle_mesh_channel_msg(msg)` (7→2), contadores compartidos |

### 6.3 Refactor de métodos largos en `src/web/http_server.py`

- `_handle_websocket_handshake` (72 → ~38 líneas): la lectura de tramas RFC 6455 se extrajo a `_read_websocket_frame(reader) → tuple[int, bytes] | None`.
- `_serve_static_file` (71 → ~40 líneas): helpers `_is_traversal_attempt`, `_is_within_static_root`, `_build_http_response`, `_write_http_response`. Se mantiene la cabecera `Cache-Control: public, max-age=3600` original.

### 6.4 Nota de mapeo (dónde vive ahora cada lógica)

- El flujo `on_mesh_event` descrito en §2.C ahora ejecuta `MeshCoreBridge.on_mesh_event → RxEventRouter.handle_event`.
- El bucle de salud de §4.D ahora es `HealthReporter._loop` (arrancado con `start()`, detenido con `stop()`).
- `handle_admin` de §2.E delega en `AdminCommandHandler.handle`; los tópicos entrantes `meshcore/tx` y `meshcore/admin/*` se procesan en `MqttInboundDispatcher`.
- Los contadores `rx_count`, `tx_count`, `tx_error_count`, `serial_reconnect_count` siguen expuestos como atributos del bridge y se comparten vía el Protocol `BridgeCounters`.

