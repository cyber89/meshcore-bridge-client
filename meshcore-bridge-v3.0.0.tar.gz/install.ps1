# ==============================================================================
# MeshCore Bridge - Script de Instalación y Ejecución para Windows PowerShell
# Versión: 3.0.0 (Producción)
# ==============================================================================

[CmdletBinding()]
param (
    [switch]$Run,
    [switch]$InstallDeps,
    [switch]$InstallDev,
    [switch]$Simulate
)

$ErrorActionPreference = "Stop"

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "    🚀 GESTOR DE MESHCORE BRIDGE PARA WINDOWS (v3.0.0)" -ForegroundColor Green
Write-Host "    Heltec / LilyGO / RAKwireless / Seeed / RP2040 <-> MQTT <-> n8n" -ForegroundColor Yellow
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# 1. Comprobar Python
Write-Host "[1/4] Verificando entorno Python..." -ForegroundColor Blue
$PythonPath = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $PythonPath) {
    $PythonPath = (Get-Command py -ErrorAction SilentlyContinue).Source
}

if (-not $PythonPath) {
    Write-Host "[ERROR] Python no fue encontrado en el PATH. Por favor instala Python 3.10+ desde python.org." -ForegroundColor Red
    exit 1
}

Write-Host "[OK] Python encontrado: $PythonPath" -ForegroundColor Green

# 2. Instalar dependencias de producción
if ($InstallDeps -or -not (Test-Path "$ScriptDir\.venv")) {
    Write-Host "[2/4] Instalando / verificando dependencias en requirements.txt..." -ForegroundColor Blue
    & $PythonPath -m pip install --upgrade pip -q
    & $PythonPath -m pip install -r "$ScriptDir\requirements.txt" -q
    Write-Host "[OK] Dependencias instaladas correctamente." -ForegroundColor Green
} else {
    Write-Host "[2/4] Dependencias ya disponibles." -ForegroundColor Green
}

# 2.1 Instalar tooling de desarrollo / QA / auditoría
if ($InstallDev) {
    Write-Host "[3/4] Instalando herramientas de desarrollo (pytest, mypy, ruff, bandit, playwright, amqtt)..." -ForegroundColor Blue
    & $PythonPath -m pip install -r "$ScriptDir\requirements-dev.txt" -q
    & $PythonPath -m pip install -e "$ScriptDir[dev]" -q 2>$null
    if (Get-Command "$ScriptDir\.venv\Scripts\playwright.exe" -ErrorAction SilentlyContinue) {
        & "$ScriptDir\.venv\Scripts\playwright.exe" install chromium
    }
    Write-Host "[OK] Tooling de desarrollo instalado." -ForegroundColor Green
}

# 3. Configurar .env si no existe
if (-not (Test-Path "$ScriptDir\.env")) {
    Write-Host "[4/4] Generando archivo .env por defecto..." -ForegroundColor Blue
    Copy-Item "$ScriptDir\.env.example" "$ScriptDir\.env" -Force
    Write-Host "[OK] Archivo .env generado a partir de .env.example." -ForegroundColor Green
} else {
    Write-Host "[4/4] Archivo .env existente detectado." -ForegroundColor Green
}

Write-Host ""
Write-Host "🎉 Configuración de MeshCore Bridge completada." -ForegroundColor Green
Write-Host "🌐 Cliente Web Station SPA: http://localhost:8080 (o http://localhost:8085 en simulación)" -ForegroundColor Green
Write-Host "Para iniciar el servicio en producción:" -ForegroundColor Cyan
Write-Host "    python -m src" -ForegroundColor Yellow
Write-Host "Para iniciar la simulación con 8 nodos LoRa y Heltec v4 USB:" -ForegroundColor Cyan
Write-Host "    python scripts/simulate_heltec_v4_mesh.py --live" -ForegroundColor Yellow
Write-Host "Para ejecutar la suite de calidad completa:" -ForegroundColor Cyan
Write-Host "    python .agents/skills/bridge-test-runner/scripts/run_checks.py" -ForegroundColor Yellow
Write-Host ""

if ($Simulate) {
    Write-Host "Iniciando simulación interactiva con 8 nodos LoRa..." -ForegroundColor Cyan
    & $PythonPath "$ScriptDir\scripts\simulate_heltec_v4_mesh.py" --live
} elseif ($Run) {
    Write-Host "Iniciando MeshCore Bridge en producción..." -ForegroundColor Cyan
    & $PythonPath -m src
}

