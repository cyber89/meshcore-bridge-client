/**
 * MapModule - Visualización cartográfica Leaflet, capas de mosaicos online y offline (MBTiles),
 * marcadores de nodos de malla, Heatmap táctico RF y trazado de rutas Traceroute.
 */

import { escapeHtml } from "../core/utils.js";
import { EVENTS } from "../core/eventbus.js";

export class MapModule {
  constructor(context) {
    this.ctx = context;
    this.map = null;
    this.tileLayers = {};
    this.mapMarkers = new Map();
    this.rfHeatmapGroup = null;
    this.rfHeatmapActive = false;
    this.rfHeatmapInterval = null;
    this.selectedTraceTarget = null;
    this.selectedTraceName = null;
    this.localTileUrl = localStorage.getItem("meshcore_local_tile_url") || "/api/map/tiles/{z}/{x}/{y}.png";
    const savedLayer = localStorage.getItem("meshcore_map_layer_mode");
    this.mapLayerMode = (savedLayer === "cartodb" || savedLayer === "tactical_radar" || !savedLayer) ? "dark" : savedLayer;
    this.dom = {};
    this._hasInitiallyCentered = false;
    this._userInteractedWithMap = false;
  }

  init() {
    this._bindElements();
    this._bindEvents();
    this._subscribeBus();
    this.initLeafletMap();
    this.initMapOverlayToggle();
    this.initAirtimeMonitoring();
    this.initTraceroute();

    if (this.ctx) {
      this.ctx.centerMapOnCoords = (lat, lon, zoom) => this.centerMapOnCoords(lat, lon, zoom);
      this.ctx.centerOnLocalNode = (zoom, showToast) => this.centerOnLocalNode(zoom, showToast);
    }
  }

  _bindElements() {
    this.dom = {
      liveGpsMap: document.getElementById("liveGpsMap"),
      mapOverlayInfo: document.getElementById("mapOverlayInfo"),
      btnToggleMapNodes: document.getElementById("btnToggleMapNodes"),
      mapOverlayHeader: document.getElementById("mapOverlayHeader"),
      mapNodesList: document.getElementById("mapNodesList"),
      mapNodesCount: document.getElementById("mapNodesCount"),
      btnCenterLocalNode: document.getElementById("btnCenterLocalNode"),
      chkMapHeatmap: document.getElementById("chkMapHeatmap"),
      mapHeatmapBadge: document.getElementById("mapHeatmapBadge"),
      tracerouteModal: document.getElementById("tracerouteModal"),
      btnCloseTracerouteModal: document.getElementById("btnCloseTracerouteModal"),
      btnExecuteTrace: document.getElementById("btnExecuteTrace"),
      traceTargetNameDisplay: document.getElementById("traceTargetNameDisplay"),
      traceTargetPkDisplay: document.getElementById("traceTargetPkDisplay"),
      traceCustomPathInput: document.getElementById("traceCustomPathInput"),
      traceStatusPill: document.getElementById("traceStatusPill"),
      traceVisualGraph: document.getElementById("traceVisualGraph"),
      traceBreakdownTableBody: document.getElementById("traceBreakdownTableBody"),
      headerDutyCycle: document.getElementById("headerDutyCycle"),
    };
  }

  _bindEvents() {
    document.querySelectorAll(".map-layer-switcher .map-layer-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const mode = btn.getAttribute("data-layer");
        if (mode) this.setMapLayer(mode);
      });
    });

    if (this.dom.btnCenterLocalNode) {
      this.dom.btnCenterLocalNode.addEventListener("click", () => {
        this._userInteractedWithMap = false;
        this.centerOnLocalNode(14, true);
      });
    }

    if (this.dom.chkMapHeatmap) {
      this.dom.chkMapHeatmap.addEventListener("change", (e) => this.setRfHeatmap(e.target.checked));
    }
  }

  _subscribeBus() {
    if (!this.ctx.eventBus) return;

    this.ctx.eventBus.on(EVENTS.TAB_CHANGED, (tabId) => {
      if (tabId === "tab-map" && this.map) {
        setTimeout(() => {
          try {
            this.map.invalidateSize();
            if (this.ctx.knownNodes && this.ctx.knownNodes.size > 0) {
              this.updateMapMarkers(Array.from(this.ctx.knownNodes.values()));
            }
            if (!this._hasInitiallyCentered) {
              this.centerOnLocalNode(13, false);
              this._hasInitiallyCentered = true;
            }
          } catch (_) {}
        }, 150);
      }
    });

    this.ctx.eventBus.on(EVENTS.NODE_UPDATED, (data) => {
      if (!data && this.ctx.knownNodes) {
        this.updateMapMarkers(Array.from(this.ctx.knownNodes.values()));
        if (!this._hasInitiallyCentered) {
          this.centerOnLocalNode(13, false);
          this._hasInitiallyCentered = true;
        }
      } else if (Array.isArray(data)) {
        this.updateMapMarkers(data);
        if (!this._hasInitiallyCentered) {
          this.centerOnLocalNode(13, false);
          this._hasInitiallyCentered = true;
        }
      } else if (data && typeof data === "object") {
        this.updateSingleNodeMarker(data);
        if ((data.is_local || data.role === "LOCAL") && !this._hasInitiallyCentered && !this._userInteractedWithMap) {
          this.centerOnLocalNode(13, false);
          this._hasInitiallyCentered = true;
        }
      }
    });

    this.ctx.eventBus.on("CENTER_MAP_COORDS", (coords) => {
      if (coords && coords.lat != null && coords.lon != null) {
        this.centerMapOnCoords(coords.lat, coords.lon, coords.zoom || 14);
      }
    });
  }

  initLeafletMap() {
    if (!this.dom.liveGpsMap) return;

    if (typeof L === "undefined") {
      if (!this._leafletRetryCount) this._leafletRetryCount = 0;
      if (this._leafletRetryCount < 20) {
        this._leafletRetryCount++;
        setTimeout(() => this.initLeafletMap(), 250);
      }
      return;
    }

    if (this.map) {
      try {
        this.map.invalidateSize();
      } catch (_) {}
      return;
    }

    try {
      this.map = L.map("liveGpsMap", {
        zoomControl: true,
        attributionControl: true,
      }).setView([20.15, -75.20], 12);

      const darkLayer = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        className: 'map-tiles-dark',
        maxZoom: 19,
      });

      const osmLayer = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19,
      });

      const satelliteLayer = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        attribution: '&copy; <a href="https://www.esri.com/">Esri</a>, Earthstar Geographics',
        maxZoom: 19,
        maxNativeZoom: 18,
      });

      this.tileLayers = {
        dark: darkLayer,
        cartodb: darkLayer,
        osm: osmLayer,
        satellite: satelliteLayer,
        local: L.tileLayer(this.localTileUrl, {
          attribution: 'MeshCore Offline Local Tiles',
          maxZoom: 18,
          errorTileUrl: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" fill="%230f172a"><rect width="256" height="256"/><text x="128" y="128" fill="%23475569" text-anchor="middle" font-size="11" font-family="sans-serif">Mosaico Local No Disponible</text></svg>',
        }),
      };

      this.rfHeatmapGroup = L.layerGroup();

      this.map.on("movestart zoomstart dragstart", () => {
        this._userInteractedWithMap = true;
      });

      this.setMapLayer(this.mapLayerMode || "dark");

      if (this.ctx.knownNodes && this.ctx.knownNodes.size > 0) {
        this.updateMapMarkers(Array.from(this.ctx.knownNodes.values()));
      }

      this.centerOnLocalNode(13, false);
    } catch (err) {
      console.warn("No se pudo inicializar el mapa Leaflet:", err);
    }
  }

  setMapLayer(mode) {
    if (!this.map || !this.tileLayers) return;

    if (mode === "tactical_radar" || !this.tileLayers[mode]) {
      mode = "dark";
    }

    Object.values(this.tileLayers).forEach((layer) => {
      if (this.map.hasLayer(layer)) {
        this.map.removeLayer(layer);
      }
    });

    const selected = this.tileLayers[mode] || this.tileLayers.dark;
    selected.addTo(this.map);
    this.mapLayerMode = mode;
    localStorage.setItem("meshcore_map_layer_mode", mode);

    document.querySelectorAll(".map-layer-switcher .map-layer-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.getAttribute("data-layer") === mode);
    });
  }

  initMapOverlayToggle() {
    const overlay = this.dom.mapOverlayInfo;
    const btnToggle = this.dom.btnToggleMapNodes;
    const header = this.dom.mapOverlayHeader;
    if (!overlay) return;

    const setMinimizedState = (minimized) => {
      overlay.classList.toggle("minimized", minimized);
      if (btnToggle) {
        const icon = btnToggle.querySelector(".toggle-icon");
        if (icon) icon.textContent = minimized ? "＋" : "−";
        btnToggle.setAttribute("aria-expanded", String(!minimized));
        btnToggle.title = minimized ? "Expandir lista de nodos" : "Minimizar lista de nodos";
      }
      localStorage.setItem("meshcore_map_nodes_minimized", String(minimized));
    };

    const savedState = localStorage.getItem("meshcore_map_nodes_minimized");
    if (savedState === "true") {
      setMinimizedState(true);
    }

    if (btnToggle) {
      btnToggle.addEventListener("click", (e) => {
        e.stopPropagation();
        setMinimizedState(!overlay.classList.contains("minimized"));
      });
    }

    if (header) {
      header.addEventListener("click", (e) => {
        if (e.target.closest("#btnToggleMapNodes")) return;
        setMinimizedState(!overlay.classList.contains("minimized"));
      });
    }
  }

  async setRfHeatmap(active) {
    if (!this.map) return;
    this.rfHeatmapActive = Boolean(active);
    this.updateRfHeatmapToggleState();

    if (!this.rfHeatmapActive) {
      if (this.rfHeatmapGroup) this.rfHeatmapGroup.clearLayers();
      if (this.rfHeatmapInterval) {
        clearInterval(this.rfHeatmapInterval);
        this.rfHeatmapInterval = null;
      }
      if (this.ctx.showToast) this.ctx.showToast(I18n.t('toast.heatmap_off'), "info");
      return;
    }

    await this.refreshRfHeatmap(true);

    if (!this.rfHeatmapInterval) {
      this.rfHeatmapInterval = setInterval(() => {
        if (this.rfHeatmapActive) this.refreshRfHeatmap(false);
      }, 10000);
    }
  }

  async toggleRfHeatmap() {
    await this.setRfHeatmap(!this.rfHeatmapActive);
  }

  updateRfHeatmapToggleState() {
    if (this.dom.chkMapHeatmap) {
      this.dom.chkMapHeatmap.checked = this.rfHeatmapActive;
    }
    if (this.dom.mapHeatmapBadge) {
      this.dom.mapHeatmapBadge.textContent = this.rfHeatmapActive ? "ON" : "OFF";
      this.dom.mapHeatmapBadge.classList.toggle("is-active", this.rfHeatmapActive);
    }
  }

  async refreshRfHeatmap(showToast = false) {
    if (!this.map || !this.rfHeatmapActive) return;

    try {
      const res = await fetch("/api/rf/heatmap", {
        headers: this.ctx.getAuthHeaders ? this.ctx.getAuthHeaders() : {},
      });
      const data = await res.json();
      if (data.status === "ok" && data.data && Array.isArray(data.data.points)) {
        if (!this.rfHeatmapGroup) this.rfHeatmapGroup = L.layerGroup();
        this.rfHeatmapGroup.clearLayers();

        const points = data.data.points;

        points.forEach((pt) => {
          const ptRssi = pt.rssi != null ? Number(pt.rssi) : -100;
          const ptSnr = pt.snr != null ? Number(pt.snr) : 0;
          const isLocal = Boolean(pt.is_local);

          const baseRadius = Math.max(500, Math.min(3500, (ptRssi + 135) * 45));

          let color = "#ef4444";
          let qualityLabel = I18n.t('signal.weak');
          if (ptRssi >= -75 || (isLocal && ptRssi >= -85)) {
            color = "#10b981";
            qualityLabel = I18n.t('signal.excellent');
          } else if (ptRssi >= -95) {
            color = "#06b6d4";
            qualityLabel = I18n.t('signal.good');
          } else if (ptRssi >= -110) {
            color = "#f59e0b";
            qualityLabel = I18n.t('signal.marginal');
          }

          const outerCircle = L.circle([pt.lat, pt.lon], {
            radius: baseRadius,
            color: color,
            fillColor: color,
            fillOpacity: 0.12,
            weight: 1,
            dashArray: "4, 4",
          });

          const innerCircle = L.circle([pt.lat, pt.lon], {
            radius: baseRadius * 0.45,
            color: color,
            fillColor: color,
            fillOpacity: 0.32,
            weight: 2,
          });

          const rssiPart = pt.rssi != null ? `${Math.round(ptRssi)} dBm` : "--";
          const snrPart = pt.snr != null ? `${ptSnr > 0 ? "+" : ""}${ptSnr.toFixed(1)} dB` : "--";
          const noisePart = pt.noise_floor != null ? `${pt.noise_floor} dBm` : "--";
          const roleLabel = pt.role || (isLocal ? "LOCAL" : "CLIENT");

          const popupHtml = `
            <div class="custom-map-popup" style="min-width: 190px;">
              <div class="popup-title" style="color: ${color};">
                <span data-lucide="flame" data-size="14"></span> <strong>${escapeHtml(pt.name)}</strong>
              </div>
              <div class="popup-info">
                <div><span>${I18n.t('map.role_label')}</span> <span class="badge-pill" style="font-size: 10px;">${escapeHtml(roleLabel)}</span></div>
                <div><span>${I18n.t('map.link_qual')}</span> <strong style="color: ${color};">${qualityLabel}</strong></div>
                <div><span>${I18n.t('map.rssi_snr')}</span> <strong>${rssiPart} / ${snrPart}</strong></div>
                <div><span>${I18n.t('map.noise_floor')}</span> <strong>${noisePart}</strong></div>
                <div><span>${I18n.t('map.cov_radius')}</span> <code>~${(baseRadius / 1000).toFixed(1)} km</code></div>
              </div>
            </div>
          `;

          innerCircle.bindPopup(popupHtml);
          outerCircle.bindPopup(popupHtml);

          this.rfHeatmapGroup.addLayer(outerCircle);
          this.rfHeatmapGroup.addLayer(innerCircle);
        });

        if (!this.map.hasLayer(this.rfHeatmapGroup)) {
          this.rfHeatmapGroup.addTo(this.map);
        }

        if (showToast && this.ctx.showToast) {
          this.ctx.showToast(I18n.t('toast.heatmap_on').replace('{n}', points.length), "success");
        }
      }
    } catch (err) {
      if (showToast && this.ctx.showToast) {
        this.ctx.showToast(I18n.t('toast.heatmap_err').replace('{err}', err.message), "error");
      }
    }
  }

  initAirtimeMonitoring() {
    this.fetchAirtimeStats();
    setInterval(() => this.fetchAirtimeStats(), 60000);
  }

  async fetchAirtimeStats() {
    try {
      const res = await fetch("/api/airtime/stats", {
        headers: this.ctx.getAuthHeaders ? this.ctx.getAuthHeaders() : {},
      });
      const data = await res.json();
      if (data.status === "ok" && data.data) {
        const stats = data.data;
        const pct = stats.hourly_duty_cycle_pct || 0.0;
        if (this.dom.headerDutyCycle) {
          this.dom.headerDutyCycle.textContent = `${pct.toFixed(1)}%`;
        }
      }
    } catch (_) {}
  }

  initTraceroute() {
    if (this.dom.btnCloseTracerouteModal) {
      this.dom.btnCloseTracerouteModal.addEventListener("click", () => {
        if (this.dom.tracerouteModal) this.dom.tracerouteModal.classList.add("hidden");
      });
    }
    if (this.dom.tracerouteModal) {
      this.dom.tracerouteModal.addEventListener("click", (e) => {
        if (e.target === this.dom.tracerouteModal) {
          this.dom.tracerouteModal.classList.add("hidden");
        }
      });
    }
    if (this.dom.btnExecuteTrace) {
      this.dom.btnExecuteTrace.addEventListener("click", () => {
        this.executeTraceroute();
      });
    }
  }

  openTracerouteModal(targetNode, targetName) {
    this.selectedTraceTarget = targetNode;
    this.selectedTraceName = targetName || (targetNode ? targetNode.slice(0, 8) : I18n.t('common.node'));

    if (this.dom.traceTargetNameDisplay) this.dom.traceTargetNameDisplay.textContent = this.selectedTraceName;
    if (this.dom.traceTargetPkDisplay) this.dom.traceTargetPkDisplay.textContent = targetNode;
    if (this.dom.traceCustomPathInput) this.dom.traceCustomPathInput.value = "";
    if (this.dom.traceStatusPill) {
      this.dom.traceStatusPill.textContent = I18n.t('map.trace_ready');
      this.dom.traceStatusPill.className = "trace-status-pill";
    }
    if (this.dom.traceVisualGraph) {
      this.dom.traceVisualGraph.innerHTML = `<div class="trace-empty-hint">Haz clic en "Iniciar Traza" para enviar una sonda multi-salto y mapear los repetidores.</div>`;
    }
    if (this.dom.traceBreakdownTableBody) {
      this.dom.traceBreakdownTableBody.innerHTML = `<tr><td colspan="6" class="text-center">Presiona "Iniciar Traza" para comenzar</td></tr>`;
    }
    if (this.dom.tracerouteModal) {
      this.dom.tracerouteModal.classList.remove("hidden");
    }
  }

  async executeTraceroute() {
    const target = this.selectedTraceTarget;
    if (!target) return;
    const customPath = this.dom.traceCustomPathInput ? this.dom.traceCustomPathInput.value.trim() : "";

    if (this.dom.traceStatusPill) {
      this.dom.traceStatusPill.textContent = I18n.t('map.trace_transmitting');
      this.dom.traceStatusPill.className = "trace-status-pill running";
    }
    if (this.dom.btnExecuteTrace) {
      this.dom.btnExecuteTrace.disabled = true;
      this.dom.btnExecuteTrace.textContent = I18n.t('map.tracing');
    }

    try {
      const res = await fetch("/api/repeater/traceroute", {
        method: "POST",
        headers: this.ctx.getAuthHeaders ? this.ctx.getAuthHeaders({ "Content-Type": "application/json" }) : { "Content-Type": "application/json" },
        body: JSON.stringify({ target_node: target, path: customPath }),
      });
      const data = await res.json();
      if (data.status === "ok" && data.data) {
        const trace = data.data;
        if (this.dom.traceStatusPill) {
          this.dom.traceStatusPill.textContent = I18n.t('map.trace_completed').replace('{hops}', trace.total_hops || 0).replace('{rtt}', trace.total_rtt_ms || 0);
          this.dom.traceStatusPill.className = "trace-status-pill success";
        }
        this.renderTracerouteGraph(trace.hops_breakdown || []);
        this.renderTracerouteTable(trace.hops_breakdown || []);
        if (this.ctx.showToast) this.ctx.showToast(I18n.t('toast.trace_completed').replace('{hops}', trace.total_hops || 0).replace('{rtt}', trace.total_rtt_ms || 0), "success");
      } else {
        if (this.dom.traceStatusPill) {
          this.dom.traceStatusPill.textContent = I18n.t('map.trace_failed');
          this.dom.traceStatusPill.className = "trace-status-pill error";
        }
        if (this.ctx.showToast) this.ctx.showToast(I18n.t('toast.trace_err').replace('{msg}', data.message || 'Sin respuesta'), "error");
      }
    } catch (err) {
      if (this.dom.traceStatusPill) {
        this.dom.traceStatusPill.textContent = I18n.t('map.trace_conn_err');
        this.dom.traceStatusPill.className = "trace-status-pill error";
      }
      if (this.ctx.showToast) this.ctx.showToast(I18n.t('toast.net_err').replace('{msg}', err.message), "error");
    } finally {
      if (this.dom.btnExecuteTrace) {
        this.dom.btnExecuteTrace.disabled = false;
        this.dom.btnExecuteTrace.textContent = I18n.t('map.start_trace');
      }
    }
  }

  renderTracerouteGraph(hops) {
    if (!this.dom.traceVisualGraph) return;
    this.dom.traceVisualGraph.innerHTML = "";
    if (!Array.isArray(hops) || hops.length === 0) return;

    hops.forEach((hop, idx) => {
      const nodeEl = document.createElement("div");
      nodeEl.className = "trace-node-item";
      const isTarget = idx === hops.length - 1;
      const isStart = idx === 0;

      nodeEl.innerHTML = `
        <div class="trace-node-circle ${isStart ? "start" : (isTarget ? "target" : "repeater")}">
          ${isStart ? "🏠" : (isTarget ? "🎯" : "📻")}
        </div>
        <div class="trace-node-name font-mono">${escapeHtml(hop.name || (hop.pubkey ? hop.pubkey.slice(0, 8) : `Hop ${idx}`))}</div>
        <div class="trace-node-snr">${hop.snr != null ? `${hop.snr} dB` : ""}</div>
      `;
      this.dom.traceVisualGraph.appendChild(nodeEl);

      if (idx < hops.length - 1) {
        const arrowEl = document.createElement("div");
        arrowEl.className = "trace-arrow";
        arrowEl.innerHTML = `<span>➔</span>`;
        this.dom.traceVisualGraph.appendChild(arrowEl);
      }
    });
  }

  renderTracerouteTable(hops) {
    if (!this.dom.traceBreakdownTableBody) return;
    this.dom.traceBreakdownTableBody.innerHTML = "";
    if (!Array.isArray(hops) || hops.length === 0) return;

    hops.forEach((h, i) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>#${i}</strong></td>
        <td><code>${escapeHtml(h.pubkey ? h.pubkey.slice(0, 8) : "--")}</code></td>
        <td>${escapeHtml(h.name || I18n.t('common.node'))}</td>
        <td><span class="badge-pill">${escapeHtml(h.role || "NODE")}</span></td>
        <td>${h.snr != null ? `${h.snr} dB` : "--"}</td>
        <td>${h.rtt_ms != null ? `${h.rtt_ms} ms` : "--"}</td>
      `;
      this.dom.traceBreakdownTableBody.appendChild(tr);
    });
  }

  centerMapOnCoords(lat, lon, zoom = 14) {
    if (!this.map) return;
    const fLat = parseFloat(lat);
    const fLon = parseFloat(lon);
    if (!isNaN(fLat) && !isNaN(fLon)) {
      this.map.setView([fLat, fLon], zoom);
    }
  }

  getLocalNodeCoordinates() {
    // 1. Buscar en knownNodes
    if (this.ctx.knownNodes) {
      for (const n of this.ctx.knownNodes.values()) {
        if (n.is_local || String(n.role).toUpperCase() === "LOCAL") {
          const lat = parseFloat(n.latitude ?? n.lat);
          const lon = parseFloat(n.longitude ?? n.lon);
          if (!isNaN(lat) && !isNaN(lon) && (lat !== 0 || lon !== 0)) {
            return { lat, lon, name: n.name || I18n.t('map.local_station'), node: n };
          }
        }
      }
    }

    // 2. Buscar en inputs del DOM de configuración
    const latEl = document.getElementById("localGpsLat");
    const lonEl = document.getElementById("localGpsLon");
    if (latEl && lonEl) {
      const lat = parseFloat(latEl.value);
      const lon = parseFloat(lonEl.value);
      if (!isNaN(lat) && !isNaN(lon) && (lat !== 0 || lon !== 0)) {
        return { lat, lon, name: I18n.t('map.local_station') };
      }
    }

    return null;
  }

  centerOnLocalNode(zoom = 13, showToast = false) {
    if (!this.map) return;
    const localCoords = this.getLocalNodeCoordinates();

    if (localCoords) {
      this.map.setView([localCoords.lat, localCoords.lon], zoom);
      const pk = localCoords.node?.public_key?.toLowerCase?.() || "local";
      const localMarker = this.mapMarkers.get(pk);
      if (localMarker && showToast) {
        localMarker.openPopup();
      }
      if (showToast && this.ctx.showToast) {
        this.ctx.showToast(I18n.t('toast.map_centered_local').replace('{lat}', localCoords.lat.toFixed(4)).replace('{lon}', localCoords.lon.toFixed(4)), "success");
      }
      return;
    }

    // Fallback: si el nodo local no tiene GPS pero hay nodos posicionados
    if (this.mapMarkers.size > 0) {
      const bounds = [];
      this.mapMarkers.forEach((m) => bounds.push(m.getLatLng()));
      if (bounds.length > 0) {
        this.map.fitBounds(L.latLngBounds(bounds), { padding: [40, 40], maxZoom: 14 });
        if (showToast && this.ctx.showToast) {
          this.ctx.showToast(I18n.t('toast.map_adjusted'), "info");
        }
        return;
      }
    }

    if (showToast && this.ctx.showToast) {
      this.ctx.showToast(I18n.t('toast.map_no_local_gps'), "warning");
    }
  }

  updateMapMarkers(nodes) {
    if (!this.map || !Array.isArray(nodes)) return;

    nodes.forEach((node) => {
      this.updateSingleNodeMarker(node);
    });

    this.updateMapNodesOverlayList(nodes);
  }

  updateMapNodesOverlayList(nodes) {
    if (!this.dom.mapNodesList) return;

    const positionedNodes = nodes.filter((n) => {
      const lat = parseFloat(n.latitude ?? n.lat);
      const lon = parseFloat(n.longitude ?? n.lon);
      return !isNaN(lat) && !isNaN(lon) && (lat !== 0 || lon !== 0);
    });

    if (this.dom.mapNodesCount) {
      this.dom.mapNodesCount.textContent = String(positionedNodes.length);
    }

    this.dom.mapNodesList.innerHTML = "";

    if (positionedNodes.length === 0) {
      this.dom.mapNodesList.innerHTML = `<div class="map-node-empty-hint">${I18n.t('map.no_gps_nodes')}</div>`;
      return;
    }

    positionedNodes.forEach((node) => {
      const lat = parseFloat(node.latitude ?? node.lat);
      const lon = parseFloat(node.longitude ?? node.lon);
      const isLocal = Boolean(node.is_local || String(node.role).toUpperCase() === "LOCAL");
      const isRepeater = String(node.role || "").toUpperCase() === "REPEATER";
      const isSensor = String(node.role || "").toUpperCase() === "SENSOR";
      const cleanName = node.name || node.alias || (node.public_key ? node.public_key.slice(0, 8) : I18n.t('common.node'));

      const itemEl = document.createElement("div");
      itemEl.className = `map-node-item ${isLocal ? "is-local local-node-item" : ""}`;
      itemEl.innerHTML = `
        <div class="map-node-item-header">
          <span class="map-node-icon">${isLocal ? "🏠" : (isRepeater ? "📡" : (isSensor ? "🌡️" : "👤"))}</span>
          <strong class="map-node-name font-mono">${escapeHtml(cleanName)}</strong>
          <span class="badge-pill" style="font-size: 9.5px;">${escapeHtml(node.role || (isLocal ? "LOCAL" : "CLIENT"))}</span>
        </div>
        <div class="map-node-item-sub font-mono">
          <span>📍 ${lat.toFixed(4)}, ${lon.toFixed(4)}</span>
          ${node.last_snr != null ? `<span>📶 ${node.last_snr} dB</span>` : ""}
        </div>
      `;

      itemEl.addEventListener("click", () => {
        this.map.setView([lat, lon], 15);
        const pk = (node.public_key || "").toLowerCase();
        const marker = this.mapMarkers.get(pk);
        if (marker) {
          marker.openPopup();
        }
      });

      this.dom.mapNodesList.appendChild(itemEl);
    });
  }

  updateSingleNodeMarker(node) {
    if (!this.map || !node) return;
    const lat = parseFloat(node.latitude ?? node.lat);
    const lon = parseFloat(node.longitude ?? node.lon);
    if (isNaN(lat) || isNaN(lon) || (lat === 0 && lon === 0)) return;

    const pk = (node.public_key || (node.is_local ? "local" : "")).toLowerCase();
    if (!pk) return;

    const isLocal = Boolean(node.is_local || String(node.role).toUpperCase() === "LOCAL");
    const isRepeater = String(node.role || "").toUpperCase() === "REPEATER";
    const isSensor = String(node.role || "").toUpperCase() === "SENSOR";
    const markerColor = isLocal ? "#10b981" : (isRepeater ? "#8b5cf6" : (isSensor ? "#f59e0b" : "#0ea5e9"));
    const iconSymbol = isLocal ? "🏠" : (isRepeater ? "📡" : (isSensor ? "🌡️" : "👤"));
    const name = node.name || node.alias || (isLocal ? I18n.t('map.local_station_you') : pk.slice(0, 8));

    const popupHtml = `
      <div class="custom-map-popup">
        <div class="popup-title" style="color: ${markerColor};">
          <span>${iconSymbol}</span> <strong>${escapeHtml(name)}</strong>
        </div>
        <div class="popup-info">
          <div><span>${I18n.t('map.role_label')}</span> <span class="badge-pill">${escapeHtml(node.role || (isLocal ? "LOCAL" : "CLIENT"))}</span></div>
          <div><span>${I18n.t('map.key_label')}</span> <code>${escapeHtml(pk.slice(0, 8))}...</code></div>
          <div><span>${I18n.t('map.pos_label')}</span> <code>${lat.toFixed(5)}, ${lon.toFixed(5)}</code></div>
          ${node.last_rssi != null ? `<div><span>${I18n.t('map.rssi_label')}</span> <strong>${node.last_rssi} dBm</strong></div>` : ""}
          ${node.last_snr != null ? `<div><span>${I18n.t('map.snr_label')}</span> <strong>${node.last_snr} dB</strong></div>` : ""}
          ${isLocal ? `<div style="color: #10b981; font-weight: 600; margin-top: 4px;">📍 ${I18n.t('map.local_connected')}</div>` : ""}
        </div>
      </div>
    `;

    if (this.mapMarkers.has(pk)) {
      const m = this.mapMarkers.get(pk);
      m.setLatLng([lat, lon]);
      m.setPopupContent(popupHtml);
      return;
    }

    const customIcon = L.divIcon({
      className: `custom-leaflet-marker ${isLocal ? "marker-local-station" : ""}`,
      html: `<div class="${isLocal ? "local-station-pulse-pin" : ""}" style="background: ${markerColor}; width: ${isLocal ? 22 : 16}px; height: ${isLocal ? 22 : 16}px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 ${isLocal ? "10px #10b981" : "6px " + markerColor}; display: flex; align-items: center; justify-content: center; font-size: ${isLocal ? "11px" : "9px"}; color: white;">${iconSymbol}</div>`,
      iconSize: [isLocal ? 22 : 16, isLocal ? 22 : 16],
      iconAnchor: [isLocal ? 11 : 8, isLocal ? 11 : 8],
    });

    const marker = L.marker([lat, lon], { icon: customIcon });
    marker.bindPopup(popupHtml);
    marker.addTo(this.map);
    this.mapMarkers.set(pk, marker);
  }
}
